// D is a Variable = %data%
var D = '%data%';

// Start bio Object
	var bio = {
		'name':'khaled Mohammed',
		'role':'Front-end Developer',
		'contacts':{
			'mobile': '+20 01015654286',
			'email':'khaled2016eng@gmail.com',
			'github':'khaled2022',
			'twitter':'@webcoder4',
			'location':'Egypt'
		},
		'welcomeMessage':'Welcome To My Resume !',
		'skills':['HTML / HTML5','CSS / CSS3','JS / JQ','BootStarp'],
		'biopic':'images/55.jpg'
	};

// Start education Object
	var education = {
		'schools' : [
		{
			'name' : 'cairo University',
			'location' : 'Egypt-cairo',
			'degree' : 'Bachelor of Computer Science',
			'majors' : ['Software Engineering',' Front-End-Web-Developer'],
			'dates' : '2019',
			'url' : 'https://www.facebook.com/Cairo.Univ/'
		}
		],
		'onlineCourses' : [
		{
			'title' : 'HTML5',
			'school' : 'youtube',
			'dates' : '2017',
			'url' : 'https://www.youtube.com'
		}]
	};

// Start work Object
	var work = {
		'jobs' : [
		{
			'employer' : 'Google',
			'title' : 'UI/UX Developer',
			'location' : 'Egypt',
			'dates' : '2017',
			'description' : 'i am a Front-end-web-developer and software enginnering'+
			' i am a Front-end-web-developer and software enginnering'+ 
			' i am a Front-end-web-developer and software enginnering..'
		},
		{
			'employer' : 'Digital-World',
			'title' : 'Front-end Developer',
			'location' : 'Egypt-Cairo',
			'dates' : '2018',
			'description' : 'i am a Front-end-web-developer and software enginnering in DigitalWorld !'
		}]
	};

// Start projects Object
	var projects = {
		'projects' : [
		{
			'title': 'Alexis Hill',
			'dates': '2018',
			'description': 'The First Design',
			'images': ['images/29.png','images/29.png']
		},
		{
			'title': 'LEX',
			'dates': '2016',
			'description': 'The second Design',
			'images': ['images/44.jpg','images/11.png','images/44.jpg']
		}]
	};

// bio Function
	bio.display = function() {

		// $ Header role&name
		$('header').prepend(HTMLheaderRole.replace(D, bio.role));
		$('header').prepend(HTMLheaderName.replace(D, bio.name));
		//$ Header biopic
		$('header').append(HTMLbioPic.replace(D,bio.biopic));
		// Formatted WelcomeMessage
		var formattedWelcomeMsg = HTMLwelcomeMsg.replace(D, bio.welcomeMessage);
		$('header').append(formattedWelcomeMsg);

		if (bio.skills.length > 0) {
			$('header').append(HTMLskillsStart);

			for (var i = 0; i < bio.skills.length; i++) {
				//Formatted Skill 
				var formattedSkill = HTMLskills.replace(D, bio.skills[i]);
				$('#skills').append(formattedSkill);
			}
		}
		// $topContacts & $FooterContacts
		$('#topContacts,#footerContacts').append(HTMLmobile.replace(D, bio.contacts.mobile));
		$('#topContacts,#footerContacts').append(HTMLemail.replace(D, bio.contacts.email));
		$('#topContacts,#footerContacts').append(HTMLtwitter.replace(D, bio.contacts.twitter));
		$('#topContacts,#footerContacts').append(HTMLgithub.replace(D, bio.contacts.github));
		$('#topContacts,#footerContacts').append(HTMLlocation.replace(D, bio.contacts.location));
		};
//bio 
	bio.display();

// eduaction Function
		education.display = function() {

		$('#education').append(HTMLschoolStart);

		if (education.schools.length > 0) {
			for (var x = 0, X = education.schools.length; x < X; x++) {
				// $ Education-entry >> schools
				$('.education-entry').append(HTMLschoolName.replace(D, education.schools[x].name));
				$('.education-entry').append(HTMLschoolDegree.replace(D, education.schools[x].degree));
				$('.education-entry').append(HTMLschoolDates.replace(D, education.schools[x].dates));
				$('.education-entry').append(HTMLschoolLocation.replace(D, education.schools[x].location));
				$('.education-entry').append(HTMLschoolMajor.replace(D, education.schools[x].majors));
			}
		}
		//$ Education Entry >> onlineClasses
		$('.education-entry').append(HTMLonlineClasses);
		
		for (var y = 0, Y = education.onlineCourses.length; y < Y; y++) {

			// $ Education-entry >> onlineCourses
			$('.education-entry').append(HTMLonlineTitle.replace(D, education.onlineCourses[y].title));
			$('.education-entry').append(HTMLonlineSchool.replace(D, education.onlineCourses[y].school));
			$('.education-entry').append(HTMLonlineDates.replace(D, education.onlineCourses[y].dates));
			$('.education-entry').append(HTMLonlineUrl.replace(D, education.onlineCourses[y].url));
		}
	
	};
//education
	education.display();

// work Function
	work.display = function() {

		if (work.jobs.length > 0) {
			for (var z = 0, Z = work.jobs.length; z < Z; z++) {
				$('#workExperience').append(HTMLworkStart);

				// FormattedEmployer >> jobs 
				var formattedEmployer = HTMLworkEmployer.replace(D, work.jobs[z].employer);
				// FormattedTitle >> jobs 
				var formattedTitle = HTMLworkTitle.replace(D, work.jobs[z].title);
				// FormattedLocation >> jobs 
				var formattedLocation = HTMLworkLocation.replace(D, work.jobs[z].location);
				// FormattedDates >> jobs 
				var formattedDates = HTMLworkDates.replace(D, work.jobs[z].dates);
				// FormattedDescription >> jobs 
				var formattedDescription = HTMLworkDescription.replace(D, work.jobs[z].description);
				//$ Work Entry last
				$('.work-entry:last').append(formattedEmployer + formattedTitle);
				$('.work-entry:last').append(formattedLocation);
				$('.work-entry:last').append(formattedDates);
				$('.work-entry:last').append(formattedDescription);
			}
		}
	};
//work
	work.display();

// projects Function
	projects.display = function() {
		if ( projects.projects.length > 0){
			for (var j = 0, J = projects.projects.length; j < J; j++) {
				$('#projects').append(HTMLprojectStart);

				// FormattedTitle >> projects
				var formattedTitle = HTMLprojectTitle.replace(D, projects.projects[j].title);
				// FormattedDates  >> projects
				var formattedDates = HTMLprojectDates.replace(D, projects.projects[j].dates);
				// FormattedDescription >> projects
				var formattedDescription = HTMLprojectDescription.replace(D, projects.projects[j].description);
				$('.project-entry:last').append(formattedTitle);
				$('.project-entry:last').append(formattedDates);
				$('.project-entry:last').append(formattedDescription);

				if (projects.projects[j].images.length > 0) {
					for (var image = 0, Img = projects.projects[j].images.length; image < Img; image++) {
						//Formatted Images >> projects
						var formattedImage = HTMLprojectImage.replace(D, projects.projects[j].images[image]);
						$('.project-entry:last').append(formattedImage);
					}
				}
			}
		}
	};
//projects
	projects.display();

//  Google Map
	$('#mapDiv').append(googleMap);



	
